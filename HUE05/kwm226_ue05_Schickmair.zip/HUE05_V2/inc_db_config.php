<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'kwm226hue05');
define('DB_PASSWORD', '.kwm.');
define('DB_DATABASE', 'kwm226_ue05_schickmair');

?>